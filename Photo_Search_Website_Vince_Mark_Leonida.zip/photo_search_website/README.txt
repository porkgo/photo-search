# Photo Search Website

This is a free static website for searching photos by name.

## Included
- `index.html` — the searchable website
- `data.json` — the photo/name database
- `images/vince-mark-leonida.png` — the first photo

## Put it online for free with GitHub Pages
1. Create a free GitHub account at github.com.
2. Create a new **public repository**, for example `photo-search`.
3. Upload `index.html`, `data.json`, and the `images` folder.
4. In the repository, open **Settings → Pages**.
5. Under the deployment/source option, choose **Deploy from a branch**.
6. Choose the `main` branch and `/ (root)`, then Save.
7. GitHub will give you your website address.

## Add another person
Add an entry to `data.json`, for example:
{
  "name": "Juan Dela Cruz",
  "photo": "images/juan-dela-cruz.jpg"
}

Then put `juan-dela-cruz.jpg` inside the `images` folder.

For 10,000 photos, keep the images in a suitable cloud storage service if the total photo size becomes too large for your GitHub Pages site. The same search page can be adapted to use image links instead of storing all photos in the website.
